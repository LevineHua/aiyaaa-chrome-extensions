import{H as a}from"./index-42a3adc5.js";export{a as HighlightJS,a as default};
